To use 3DMeshMetric, you need to download Qt4.8

